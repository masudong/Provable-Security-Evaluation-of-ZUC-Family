from gurobipy import *
import time
import math

TimeLimit = 1000000
Mm = 16
weight = [
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0]
S0 = [
	0x3e,0x72,0x5b,0x47,0xca,0xe0,0x00,0x33,0x04,0xd1,0x54,0x98,0x09,0xb9,0x6d,0xcb,
	0x7b,0x1b,0xf9,0x32,0xaf,0x9d,0x6a,0xa5,0xb8,0x2d,0xfc,0x1d,0x08,0x53,0x03,0x90,
	0x4d,0x4e,0x84,0x99,0xe4,0xce,0xd9,0x91,0xdd,0xb6,0x85,0x48,0x8b,0x29,0x6e,0xac,
	0xcd,0xc1,0xf8,0x1e,0x73,0x43,0x69,0xc6,0xb5,0xbd,0xfd,0x39,0x63,0x20,0xd4,0x38,
	0x76,0x7d,0xb2,0xa7,0xcf,0xed,0x57,0xc5,0xf3,0x2c,0xbb,0x14,0x21,0x06,0x55,0x9b,
	0xe3,0xef,0x5e,0x31,0x4f,0x7f,0x5a,0xa4,0x0d,0x82,0x51,0x49,0x5f,0xba,0x58,0x1c,
	0x4a,0x16,0xd5,0x17,0xa8,0x92,0x24,0x1f,0x8c,0xff,0xd8,0xae,0x2e,0x01,0xd3,0xad,
	0x3b,0x4b,0xda,0x46,0xeb,0xc9,0xde,0x9a,0x8f,0x87,0xd7,0x3a,0x80,0x6f,0x2f,0xc8,
	0xb1,0xb4,0x37,0xf7,0x0a,0x22,0x13,0x28,0x7c,0xcc,0x3c,0x89,0xc7,0xc3,0x96,0x56,
	0x07,0xbf,0x7e,0xf0,0x0b,0x2b,0x97,0x52,0x35,0x41,0x79,0x61,0xa6,0x4c,0x10,0xfe,
	0xbc,0x26,0x95,0x88,0x8a,0xb0,0xa3,0xfb,0xc0,0x18,0x94,0xf2,0xe1,0xe5,0xe9,0x5d,
	0xd0,0xdc,0x11,0x66,0x64,0x5c,0xec,0x59,0x42,0x75,0x12,0xf5,0x74,0x9c,0xaa,0x23,
	0x0e,0x86,0xab,0xbe,0x2a,0x02,0xe7,0x67,0xe6,0x44,0xa2,0x6c,0xc2,0x93,0x9f,0xf1,
	0xf6,0xfa,0x36,0xd2,0x50,0x68,0x9e,0x62,0x71,0x15,0x3d,0xd6,0x40,0xc4,0xe2,0x0f,
	0x8e,0x83,0x77,0x6b,0x25,0x05,0x3f,0x0c,0x30,0xea,0x70,0xb7,0xa1,0xe8,0xa9,0x65,
	0x8d,0x27,0x1a,0xdb,0x81,0xb3,0xa0,0xf4,0x45,0x7a,0x19,0xdf,0xee,0x78,0x34,0x60]

S1 = [
	0x55,0xc2,0x63,0x71,0x3b,0xc8,0x47,0x86,0x9f,0x3c,0xda,0x5b,0x29,0xaa,0xfd,0x77,
	0x8c,0xc5,0x94,0x0c,0xa6,0x1a,0x13,0x00,0xe3,0xa8,0x16,0x72,0x40,0xf9,0xf8,0x42,
	0x44,0x26,0x68,0x96,0x81,0xd9,0x45,0x3e,0x10,0x76,0xc6,0xa7,0x8b,0x39,0x43,0xe1,
	0x3a,0xb5,0x56,0x2a,0xc0,0x6d,0xb3,0x05,0x22,0x66,0xbf,0xdc,0x0b,0xfa,0x62,0x48,
	0xdd,0x20,0x11,0x06,0x36,0xc9,0xc1,0xcf,0xf6,0x27,0x52,0xbb,0x69,0xf5,0xd4,0x87,
	0x7f,0x84,0x4c,0xd2,0x9c,0x57,0xa4,0xbc,0x4f,0x9a,0xdf,0xfe,0xd6,0x8d,0x7a,0xeb,
	0x2b,0x53,0xd8,0x5c,0xa1,0x14,0x17,0xfb,0x23,0xd5,0x7d,0x30,0x67,0x73,0x08,0x09,
	0xee,0xb7,0x70,0x3f,0x61,0xb2,0x19,0x8e,0x4e,0xe5,0x4b,0x93,0x8f,0x5d,0xdb,0xa9,
	0xad,0xf1,0xae,0x2e,0xcb,0x0d,0xfc,0xf4,0x2d,0x46,0x6e,0x1d,0x97,0xe8,0xd1,0xe9,
	0x4d,0x37,0xa5,0x75,0x5e,0x83,0x9e,0xab,0x82,0x9d,0xb9,0x1c,0xe0,0xcd,0x49,0x89,
	0x01,0xb6,0xbd,0x58,0x24,0xa2,0x5f,0x38,0x78,0x99,0x15,0x90,0x50,0xb8,0x95,0xe4,
	0xd0,0x91,0xc7,0xce,0xed,0x0f,0xb4,0x6f,0xa0,0xcc,0xf0,0x02,0x4a,0x79,0xc3,0xde,
	0xa3,0xef,0xea,0x51,0xe6,0x6b,0x18,0xec,0x1b,0x2c,0x80,0xf7,0x74,0xe7,0xff,0x21,
	0x5a,0x6a,0x54,0x1e,0x41,0x31,0x92,0x35,0xc4,0x33,0x07,0x0a,0xba,0x7e,0x0e,0x34,
	0x88,0xb1,0x98,0x7c,0xf3,0x3d,0x60,0x6c,0x7b,0xca,0xd3,0x1f,0x32,0x65,0x04,0x28,
	0x64,0xbe,0x85,0x9b,0x2f,0x59,0x8a,0xd7,0xb0,0x25,0xac,0xaf,0x12,0x03,0xe2,0xf2]

def three_way_fork(M, x, y, z):  # x2 = x0 ⊕ x1

    for i in range(len(x)):
        M.addConstr(- x[i] - y[i] - z[i] >= -2)
        M.addConstr(- x[i] + y[i] + z[i] >= 0)
        M.addConstr(x[i] - y[i] + z[i] >= 0)
        M.addConstr(x[i] + y[i] - z[i] >= 0)


def funcADD(M, x, y, z, s):

    M.addConstr(s[len(x)] == 0)

    for i in range(len(x)):
        M.addConstr(s[i + 1] - z[i] - x[i] + y[i] + s[i] >= 0)
        M.addConstr(s[i + 1] - z[i] + x[i] - y[i] + s[i] >= 0)
        M.addConstr(s[i + 1] + z[i] - x[i] - y[i] + s[i] >= 0)

        M.addConstr(s[i + 1] + z[i] + x[i] - y[i] - s[i] >= 0)
        M.addConstr(s[i + 1] + z[i] - x[i] + y[i] - s[i] >= 0)
        M.addConstr(s[i + 1] - z[i] + x[i] + y[i] - s[i] >= 0)

        M.addConstr(- s[i + 1] + z[i] + x[i] + y[i] + s[i] >= 0)
        M.addConstr(- s[i + 1] - z[i] - x[i] - y[i] - s[i] >= -4)


def wt(a):
    sum = 0
    a_weight = [0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4]

    for i in range(16):
        sum += a_weight[(a >> (4 * i)) & 0xf]
    return sum

def Xor_wt(M, XorInput, Xor_wt_ineq):
    for i in range(len(Xor_wt_ineq)):
        constrain = LinExpr()
        for j in range(len(XorInput)):
            constrain += Xor_wt_ineq[i][j] * XorInput[j]
        M.addConstr(constrain >= - Xor_wt_ineq[i][len(Xor_wt_ineq[i]) - 1])


def read_ineq(FileName, size):
    myfile = open(FileName, "rb").read()
    myfile = str(myfile)
    myfile = myfile.replace("b'", "")
    myfile = myfile.replace("'", "")
    myfile = myfile.replace(",", "")
    myfile = myfile.replace("\\r", "")
    myfile = myfile.replace("\\n", " ")
    myfile = myfile.replace("\n", ",")

    myfile = myfile.split(" ")

    ineq = [([]) for i in range(int(len(myfile) / size))]
    for i in range(len(myfile)):
        # print(int(myfile[i], 10))
        ineq[int(i / size)].append(int(myfile[i], 10))
    return ineq

S0_Line = []
S0_eq_number = [1, 2690, 2378, 165, 71]
for i in range(len(S0_eq_number)):
    eq_name = "S0_LAT[" + str(i) + "]=" + str(S0_eq_number[i]) + ".txt"
    S0_Line.append(read_ineq(eq_name, 17))

S1_Line = []
S1_eq_number = [1, 5316, 4550, 4880, 4464, 3600, 4579, 3767, 1127]
for i in range(len(S1_eq_number)):
    eq_name = "S1_LAT[" + str(i) + "]=" + str(S1_eq_number[i]) + ".txt"
    S1_Line.append(read_ineq(eq_name, 17))

def funcSbox(M, Input, Output, Q_pb):

    V = []

    for i in range(4):
        V.append(Output[(8 * i):(8 * (i + 1))] + Input[(8 * i):(8 * (i + 1))])

    for j in range(len(V)):
        if (j % 2) == 0:
            for m in range(len(S1_eq_number)):
                for i in S1_Line[m]:
                    constrain = LinExpr()
                    for k in range(len(i) - 1):
                        constrain += i[k] * V[j][k]
                    constrain += i[len(i) - 1]
                    constrain += Mm
                    constrain -= Mm * Q_pb[j][m]
                    M.addConstr(constrain >= 0)
            constrain = LinExpr()
            for m in range(len(S1_eq_number)):
                constrain += Q_pb[j][m]
            M.addConstr(constrain == 1)
        else:
            for m in range(len(S0_eq_number)):
                for i in S0_Line[m]:
                    constrain = LinExpr()
                    for k in range(len(i) - 1):
                        constrain += i[k] * V[j][k]
                    constrain += i[len(i) - 1]
                    constrain += Mm
                    constrain -= Mm * Q_pb[j][m]
                    M.addConstr(constrain >= 0)
            constrain = LinExpr()
            for m in range(len(S0_eq_number)):
                constrain += Q_pb[j][m]
            M.addConstr(constrain == 1)

Xor_wt6_ineq = read_ineq("Xor6=32.txt", 7)  #

# L1_original = (L1|I) where M is the MixColumns matrix.
L1 = [
    0x0000000101040405,
    0x000000020208080a,
    0x0000000404101014,
    0x0000000808202028,
    0x0000001010404050,
    0x00000020208080a0,
    0x0000004041010140,
    0x0000008082020280,
    0x0000010004040501,
    0x0000020008080a02,
    0x0000040010101404,
    0x0000080020202808,
    0x0000100040405010,
    0x000020008080a020,
    0x0000400001014041,
    0x0000800002028082,
    0x0001000004050104,
    0x00020000080a0208,
    0x0004000010140410,
    0x0008000020280820,
    0x0010000040501040,
    0x0020000080a02080,
    0x0040000001404101,
    0x0080000002808202,
    0x0100000005010404,
    0x020000000a020808,
    0x0400000014041010,
    0x0800000028082020,
    0x1000000050104040,
    0x20000000a0208080,
    0x4000000040410101,
    0x8000000080820202,
]
L2 = [
    0x0000000140404101,
    0x0000000280808202,
    0x0000000401010405,
    0x000000080202080a,
    0x0000001004041014,
    0x0000002008082028,
    0x0000004010104050,
    0x00000080202080a0,
    0x0000010040410140,
    0x0000020080820280,
    0x0000040001040501,
    0x0000080002080a02,
    0x0000100004101404,
    0x0000200008202808,
    0x0000400010405010,
    0x000080002080a020,
    0x0001000041014040,
    0x0002000082028080,
    0x0004000004050101,
    0x00080000080a0202,
    0x0010000010140404,
    0x0020000020280808,
    0x0040000040501010,
    0x0080000080a02020,
    0x0100000001404041,
    0x0200000002808082,
    0x0400000005010104,
    0x080000000a020208,
    0x1000000014040410,
    0x2000000028080820,
    0x4000000050101040,
    0x80000000a0202080,
]
L1_flag = []
for i in range(len(L1)):
    L1_flag.append([])
    for j in range(64):
        if ((L1[i] >> j) & 0x1) == 1:
            L1_flag[i].append(j)

L2_flag = []
for i in range(len(L2)):
    L2_flag.append([])
    for j in range(64):
        if ((L2[i] >> j) & 0x1) == 1:
            L2_flag[i].append(j)


def Pmask(M, Input_P, Output_PM, Matrix_flag):
    for j in range(32):
        XorInput = []
        for k in range(len(Matrix_flag[j])):
            if Matrix_flag[j][k] >= 32:
                XorInput.append(Output_PM[Matrix_flag[j][k] - 32])
            else:
                XorInput.append(Input_P[Matrix_flag[j][k]])

        if len(XorInput) == 6:
            Xor_wt(M, XorInput, Xor_wt6_ineq)
        else:
            print("Error！！！\n", len(XorInput))


def xunhuan16(m1, m2, m1_xunhuan16, m2_xunhuan16):
    for j in range(16):  # m1_xunhuan16 = m1^L, m2^H, m2_xunhuan16 = m2^L, m1^H
        m1_xunhuan16[j + 16] = m1[j]
        m1_xunhuan16[j] = m2[j + 16]

        m2_xunhuan16[j + 16] = m2[j]
        m2_xunhuan16[j] = m1[j + 16]

def funADD_S_Matrix(t1, t2, t, S):
    M = []
    C = []
    for i in range(2):
        M.append([])
        C.append([])
        for j in range(2):
            M[i].append([])
            C[i].append([])
            for k in range(2):
                M[i][j].append(0)

    for x1 in range(1 << 8):
        for x2 in range(1 << 8):
            for c1 in range(2):
                temp1 = c1 + x1 + S[x2]
                u1 = temp1 >> 8
                f = weight[(t & temp1) ^ (t1 & x1) ^ (t2 & x2)]
                M[f][u1][c1] += 1

    for u0 in range(2):
        for c0 in range(2):
            C[u0][c0] = M[0][u0][c0] - M[1][u0][c0]
    return C

def funADD_S(x1, x2, y):
    c1 = [[1, 0], [0, 1]]
    HH1 = [(0) for i in range(4)]
    temp = [([0] * 2) for i in range(2)]

    for i in range(4):
        if (i % 2) == 1:
            HH1[i] = funADD_S_Matrix((x1 >> (8 * i)) & 0xff, (x2 >> (8 * i)) & 0xff, (y >> (8 * i)) & 0xff, S0)
        else:
            HH1[i] = funADD_S_Matrix((x1 >> (8 * i)) & 0xff, (x2 >> (8 * i)) & 0xff, (y >> (8 * i)) & 0xff, S1)

    for i in range(4):
        for j in range(2):
            for n in range(2):
                temp[j][n] = 0
                for k in range(2):
                    if HH1[i][j][k] != 0:
                        temp[j][n] += HH1[i][j][k] * c1[k][n]
        for j in range(2):
            for n in range(2):
                c1[j][n] = temp[j][n]
                # print (c1)
    maxH1_a = 0
    for i in range(2):
        maxH1_a += c1[i][0]
    return maxH1_a

def ConstrainsModel(k1_i, Beta_i):

    #Block_m1_p, Block_m2_p
    M = Model()
    M.setParam("TimeLimit", TimeLimit)
    m = []  #
    Alpha = []
    Beta = []
    K = []
    m1_p = []
    m2_p = []
    m1_xunhuan16 = []
    m2_xunhuan16 = []
    Q_pb = []

    for i in range(2):
        Q_pb.append([])
        for j in range(4):
            Q_pb[i].append([])
            if (j % 2) == 1:
                for k in range(len(S0_eq_number)):
                    Q_pb[i][j].append(M.addVar(vtype=GRB.BINARY, name="Q_pb[" + str(i) + "][" + str(j) + "][" + str(k) + "]"))
            else:
                for k in range(len(S1_eq_number)):
                    Q_pb[i][j].append(M.addVar(vtype=GRB.BINARY, name="Q_pb[" + str(i) + "][" + str(j) + "][" + str(k) + "]"))

    Add_s = []
    for i in range(3):
        Add_s.append([])
        for j in range(33):
            Add_s[i].append(M.addVar(vtype=GRB.BINARY, name="Add_s[" + str(i) + "][" + str(j) + "]"))

    for i in range(2):
        K.append([])
        for j in range(32):
            K[i].append(M.addVar(vtype=GRB.BINARY, name="k[" + str(i) + "][" + str(j) + "]"))


    for i in range(4):
        m.append([])
        for j in range(32):
            m[i].append(M.addVar(vtype=GRB.BINARY, name="m[" + str(i) + "][" + str(j) + "]"))


    for i in range(32):
        Alpha.append(M.addVar(vtype=GRB.BINARY, name="Alpha[" + str(i) + "]"))
        m1_p.append(M.addVar(vtype=GRB.BINARY, name="m1_p[" + str(i) + "]"))
        m2_p.append(M.addVar(vtype=GRB.BINARY, name="m2_p[" + str(i) + "]"))
        Beta.append(M.addVar(vtype=GRB.BINARY, name="Beta[" + str(i) + "]"))
        m1_xunhuan16.append([])
        m2_xunhuan16.append([])

    constrain = LinExpr()
    for i in range(len(m[1])):
        constrain += m[1][i]
    M.addConstr(constrain >= 1)

    xunhuan16(m[3], m[2], m1_xunhuan16, m2_xunhuan16)

    funcADD(M, m[0], m[2], Alpha, Add_s[0])
    Pmask(M, m2_p, m2_xunhuan16, L2_flag)

    funcADD(M, m[0], m[1], m[3], Add_s[1])
    Pmask(M, m1_p, m1_xunhuan16, L1_flag)

    funcADD(M, K[0], K[1], Beta, Add_s[2])

    funcSbox(M, m1_p, K[0], Q_pb[0])
    funcSbox(M, m2_p, K[1], Q_pb[1])

    for i in range(4):
        if ((k1_i >> i) & 0x1) == 1:
            constrain_k1_i = LinExpr()
            for j in range(8):
                constrain_k1_i += K[0][j+8*i]
            M.addConstr(constrain_k1_i >= 1)
        else:
            for j in range(8):
                M.addConstr(K[0][j+8*i] == 0)

        if ((Beta_i >> i) & 0x1) == 1:
            constrain_Beta_i = LinExpr()
            for j in range(8):
                constrain_Beta_i += Beta[j+8*i]
            M.addConstr(constrain_Beta_i >= 1)
        else:
            for j in range(8):
                M.addConstr(Beta[j+8*i] == 0)


    obj1 = LinExpr()

    for i in range(3):
        for j in range(1, 32):
            obj1 += Add_s[i][j]

    xishu_S0 = [0, 4, 3, 2.415, 2]
    xishu_S1 = [0, 6, 5, 4.415037, 4, 3.678071, 3.415037, 3.192645, 3]
    for i in range(2):
        for j in range(4):
            if (j % 2) == 0:
                for k in range(len(xishu_S1)):
                    obj1 += xishu_S1[k] * Q_pb[i][j][k]
            else:
                for k in range(len(xishu_S0)):
                    obj1 += xishu_S0[k] * Q_pb[i][j][k]

    M.setObjective(obj1, GRB.MINIMIZE)

    M.update()

    LPname = "ADD2_Line.lp"
    M.write(LPname)

    M.Params.MIPFocus = 2

    M.optimize()

    if M.Status == 2:  # the model is feasible

        ConstrainsName_sol = "ADD2_Line.sol"
        M.write(ConstrainsName_sol)
        print("obj", M.objVal)

        fp = open("ZUC_k1 is active in " + str(k1_i) + " bytes and Beta is active in "+ str(Beta_i) + " bytes = " +str(M.objVal) + ".txt", "w")

        fp.write("time:{}s, result:{} \n\n".format(TimeLimit, M.objVal))

        temp = 0
        for i in range(len(Alpha)):
            temp ^= round(Alpha[i].x) << i
        fp.write("Alpha: {:#010x} , \n".format(temp))

        # fp.write("Lambda[{}]: {:#010x} , \n\n".format(i, temp))

        for i in range(len(m)):
            temp = 0
            for j in range(len(m[i])):
                temp ^= round(m[i][j].x) << j
            fp.write("m[{}]: {:#010x} , \n".format(i, temp))
        fp.write("\n")

        for i in range(len(K)):
            temp = 0
            for j in range(len(K[i])):
                temp ^= round(K[i][j].x) << j
            fp.write("k[{}]: {:#010x} , \n".format(i, temp))
        fp.write("\n")

        temp = 0
        for i in range(len(Beta)):
            temp ^= round(Beta[i].x) << i
        fp.write("Beta: {:#010x} , \n\n".format(temp))

        temp = 0
        for i in range(len(m1_p)):
            temp ^= round(m1_p[i].x) << i
        fp.write("m1_p: {:#010x} , \n".format(temp))

        temp = 0
        for i in range(len(m2_p)):
            temp ^= round(m2_p[i].x) << i
        fp.write("m2_p: {:#010x} , \n\n".format(temp))

        temp = 0
        for i in range(len(m1_xunhuan16)):
            temp ^= round(m1_xunhuan16[i].x) << i
        fp.write("m1_xunhuan16: {:#010x} , \n".format(temp))

        temp = 0
        for i in range(len(m2_xunhuan16)):
            temp ^= round(m2_xunhuan16[i].x) << i
        fp.write("m2_xunhuan16: {:#010x} , \n\n".format(temp))

        for i in range(len(Add_s)):
            sum = 0
            for j in range(1, len(Add_s[i])-1):
                if round(Add_s[i][j].x) != 0:
                    sum += 1
                    fp.write("Add_s[{}][{}]: {} , \n".format(i, j, round(Add_s[i][j].x)))
            fp.write("Add2: {}\n\n".format(sum))

        for i in range(len(Q_pb)):  # 2
            for j in range(len(Q_pb[i])):  # 4
                for k in range(len(Q_pb[i][j])):  # 2
                    if round(Q_pb[i][j][k].x) != 0 and k != 0:
                        fp.write("Q_pb[{}][{}][{}]: {} , \n".format(i, j, k, round(Q_pb[i][j][k].x)))
            fp.write("\n")
        fp.close()

def main():

    for k1_i in range(1, 0x10):
        for Beta_i in range(1, 0x10):
            if ((((k1_i >> 3) & 0x1) + ((k1_i >> 2) & 0x1) + ((k1_i >> 1) & 0x1) + (k1_i & 0x1)) == 1) \
                    and ((((Beta_i >> 3) & 0x1) + ((Beta_i >> 2) & 0x1) + ((Beta_i >> 1) & 0x1) + (Beta_i & 0x1)) == 1):
                continue
            ConstrainsModel(k1_i, Beta_i)




if __name__ == '__main__':
    main()
